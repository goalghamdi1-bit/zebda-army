# ZEBDA Army — Android

A native Kotlin Android Studio project. Open this `android-app` folder in Android Studio and run the `app` configuration on an Android 8.0+ device or emulator.

## Included

- A ZEBDA Army screen with start/stop controls and a live service status.
- `ArmyForegroundService`, which handles start and stop actions in `onStartCommand`.
- An ongoing notification with an app shortcut and a Stop action.
- Android 13+ notification permission handling.
- A notification channel and Android 14+ `specialUse` foreground-service declaration.

The foreground service currently demonstrates a user-started, persistent status notification. Replace the special-use subtype description and service type if the app later performs a different ongoing task; Android requires the declared foreground-service type to match the real work.
