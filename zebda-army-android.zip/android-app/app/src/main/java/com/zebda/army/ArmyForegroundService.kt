package com.zebda.army

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class ArmyForegroundService : Service() {
    private val counterHandler = Handler(Looper.getMainLooper())
    private var serviceRunning = false

    private val counterRunnable = object : Runnable {
        override fun run() {
            if (!serviceRunning) return
            incrementButterCount()
            vibrateForButter()
            counterHandler.postDelayed(this, COUNTER_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> {
                stopArmyService()
                START_NOT_STICKY
            }
            else -> {
                val wasRunning = serviceRunning
                // Start foreground immediately, before doing the ongoing counting work.
                val notification = createNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                serviceRunning = true
                updateRunningState(true)
                if (intent?.action == ACTION_ADD_BUTTER) {
                    incrementButterCount()
                    vibrateForButter()
                }
                if (!wasRunning) {
                    counterHandler.removeCallbacks(counterRunnable)
                    counterHandler.postDelayed(counterRunnable, COUNTER_INTERVAL_MS)
                }
                START_STICKY
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceRunning = false
        counterHandler.removeCallbacks(counterRunnable)
        updateRunningState(false)
        super.onDestroy()
    }

    private fun createNotification(): Notification {
        val butterCount = getButterCount()
        val openAppIntent = PendingIntent.getActivity(
            this,
            OPEN_REQUEST_CODE,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this,
            STOP_REQUEST_CODE,
            Intent(this, ArmyForegroundService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("ZEBDA Army · 🧈 $butterCount")
            .setContentText("Counting butter emojis in the background.")
            .setContentIntent(openAppIntent)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    private fun incrementButterCount() {
        val preferences = getSharedPreferences(PREFERENCES, MODE_PRIVATE)
        val nextCount = preferences.getInt(PREF_BUTTER_COUNT, 0) + 1
        preferences.edit().putInt(PREF_BUTTER_COUNT, nextCount).apply()
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, createNotification())
        sendBroadcast(
            Intent(ACTION_STATE_CHANGED)
                .setPackage(packageName)
                .putExtra(EXTRA_BUTTER_COUNT, nextCount)
        )
    }

    private fun getButterCount(): Int =
        getSharedPreferences(PREFERENCES, MODE_PRIVATE)
            .getInt(PREF_BUTTER_COUNT, 0)

    @Suppress("DEPRECATION")
    private fun vibrateForButter() {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        } ?: return

        if (vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(VIBRATION_DURATION_MS, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ZEBDA Army service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows the butter emoji count while ZEBDA Army is counting."
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun stopArmyService() {
        serviceRunning = false
        counterHandler.removeCallbacks(counterRunnable)
        updateRunningState(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun updateRunningState(running: Boolean) {
        getSharedPreferences(PREFERENCES, MODE_PRIVATE)
            .edit()
            .putBoolean(PREF_RUNNING, running)
            .apply()
        sendBroadcast(Intent(ACTION_STATE_CHANGED).setPackage(packageName))
    }

    companion object {
        const val ACTION_START = "com.zebda.army.action.START"
        const val ACTION_STOP = "com.zebda.army.action.STOP"
        const val ACTION_ADD_BUTTER = "com.zebda.army.action.ADD_BUTTER"
        const val ACTION_STATE_CHANGED = "com.zebda.army.action.STATE_CHANGED"
        const val PREFERENCES = "zebda_army_service"
        const val PREF_RUNNING = "service_running"
        const val PREF_BUTTER_COUNT = "butter_count"
        const val EXTRA_BUTTER_COUNT = "butter_count"

        private const val CHANNEL_ID = "zebda_army_foreground"
        private const val NOTIFICATION_ID = 4201
        private const val OPEN_REQUEST_CODE = 4202
        private const val STOP_REQUEST_CODE = 4203
        private const val COUNTER_INTERVAL_MS = 5_000L
        private const val VIBRATION_DURATION_MS = 120L
    }
}
