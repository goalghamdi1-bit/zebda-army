package com.zebda.army

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusLabel: TextView
    private lateinit var butterCountLabel: TextView
    private lateinit var statusDot: View
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var butterButton: Button

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(14, 43, 34)
        window.navigationBarColor = Color.rgb(14, 43, 34)
        window.decorView.systemUiVisibility = 0
        setContentView(createContent())

        val filter = IntentFilter(ArmyForegroundService.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(stateReceiver, filter)
        }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::statusLabel.isInitialized) refreshStatus()
    }

    override fun onDestroy() {
        unregisterReceiver(stateReceiver)
        super.onDestroy()
    }

    private fun createContent(): View {
        val background = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(32), dp(28), dp(32))
            setBackgroundColor(Color.rgb(14, 43, 34))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            background = rounded(Color.rgb(247, 244, 231), dp(24))
        }
        background.addView(content, LinearLayout.LayoutParams(-1, -2))

        content.addView(text("ZEBDA", 14, Color.rgb(59, 112, 75), true).apply {
            letterSpacing = 0.22f
        })
        content.addView(text("ARMY", 38, Color.rgb(20, 55, 40), true).apply {
            letterSpacing = 0.08f
            setPadding(0, dp(5), 0, dp(6))
        })
        content.addView(text(
            "Your presence, always on.",
            16,
            Color.rgb(84, 91, 79),
            false
        ))
        butterCountLabel = text("🧈 0", 24, Color.rgb(20, 55, 40), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }
        content.addView(butterCountLabel, columnParams())

        butterButton = Button(this).apply {
            text = "ارسل زبدة"
            isAllCaps = false
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(43, 111, 68), dp(14))
            setOnClickListener { sendButter() }
        }
        content.addView(butterButton, columnParams(top = 14, height = 54))

        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(Color.rgb(234, 235, 218), dp(14))
        }
        statusDot = View(this).apply {
            background = rounded(Color.rgb(145, 151, 131), dp(20))
        }
        statusCard.addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)))
        statusLabel = text("Service is stopped", 15, Color.rgb(42, 57, 44), true).apply {
            setPadding(dp(11), 0, 0, 0)
        }
        statusCard.addView(statusLabel)
        content.addView(statusCard, columnParams(top = 24))

        startButton = Button(this).apply {
            text = "START SERVICE"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(43, 111, 68), dp(14))
            setOnClickListener { requestNotificationPermissionAndStart() }
        }
        content.addView(startButton, columnParams(top = 18, height = 54))

        stopButton = Button(this).apply {
            text = "Stop service"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.rgb(43, 67, 48))
            background = rounded(Color.rgb(226, 228, 210), dp(14))
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, ArmyForegroundService::class.java)
                        .setAction(ArmyForegroundService.ACTION_STOP)
                )
            }
        }
        content.addView(stopButton, columnParams(top = 10, height = 52))
        content.addView(text(
            "Counts butter emojis every five seconds and vibrates while the service is running.",
            13,
            Color.rgb(107, 109, 94),
            false
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }, columnParams())

        return background
    }

    private fun requestNotificationPermissionAndStart() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_NOTIFICATIONS
            )
            return
        }
        startArmyService()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIFICATIONS && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startArmyService()
        }
    }

    private fun startArmyService() {
        val intent = Intent(this, ArmyForegroundService::class.java)
            .setAction(ArmyForegroundService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun refreshStatus() {
        val preferences = getSharedPreferences(ArmyForegroundService.PREFERENCES, MODE_PRIVATE)
        val running = preferences
            .getBoolean(ArmyForegroundService.PREF_RUNNING, false)
        val butterCount = preferences.getInt(ArmyForegroundService.PREF_BUTTER_COUNT, 0)
        butterCountLabel.text = "🧈 $butterCount"
        statusLabel.text = if (running) "Service is running" else "Service is stopped"
        statusDot.background = rounded(
            if (running) Color.rgb(52, 142, 82) else Color.rgb(145, 151, 131),
            dp(20)
        )
        startButton.isEnabled = !running
        stopButton.isEnabled = running
        startButton.alpha = if (running) 0.55f else 1f
        stopButton.alpha = if (running) 1f else 0.55f
    }

    private fun sendButter() {
        val preferences = getSharedPreferences(ArmyForegroundService.PREFERENCES, MODE_PRIVATE)
        val running = preferences.getBoolean(ArmyForegroundService.PREF_RUNNING, false)
        if (running) {
            startService(
                Intent(this, ArmyForegroundService::class.java)
                    .setAction(ArmyForegroundService.ACTION_ADD_BUTTER)
            )
        } else {
            val nextCount = preferences.getInt(ArmyForegroundService.PREF_BUTTER_COUNT, 0) + 1
            preferences.edit().putInt(ArmyForegroundService.PREF_BUTTER_COUNT, nextCount).apply()
            refreshStatus()
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun columnParams(top: Int = 0, height: Int = -2) =
        LinearLayout.LayoutParams(-1, height).apply {
            if (top > 0) topMargin = dp(top)
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_NOTIFICATIONS = 101
    }
}
